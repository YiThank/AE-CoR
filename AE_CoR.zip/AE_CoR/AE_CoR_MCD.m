clc; clear;


% -------------------------------Data input and preprocessing-------------------------------
% normal_data_path = 'C:\Spectral_residual\DataCube_normal_data.mat';
% necrotic_data_path = 'C:\Spectral residual\0329-G2\Cropped\mat_labeled_separated_all\cropped_DataCube5R_data.mat';
% label_path = 'C:\Spectral residual\0329-G2\Cropped\mat_labeled_separated_all\cropped_DataCube5R_labels.mat';
normal_data_path = 'C:\Spectral residual\0329-G2\Cropped\mat_labeled_separated_all\cropped_DataCube2R_normal_data.mat';
necrotic_data_path = 'C:\Spectral residual\0329-G2\Cropped\mat_labeled_separated_all\cropped_DataCube3R_combined_data.mat';
label_path = 'C:\Spectral residual\0329-G2\Cropped\mat_labeled_separated_all\cropped_DataCube3R_labels.mat'; % 添加标签路径

normal_data = load(normal_data_path, 'normal_spec');  
normal_spec = normal_data.normal_spec;  
necrotic_data = load(necrotic_data_path, 'combined_spec');
necrotic_spec = necrotic_data.combined_spec;  
labels_all = load(label_path, 'labels_all');  
labels_all = labels_all.labels_all;

X_spectral = normal_spec(:, 1:9);
X_coords = normal_spec(:, 10:11);
XTest_spectral = necrotic_spec(:, 1:9);
XTest_coords = necrotic_spec(:, 10:11);

X_spectral = (X_spectral - mean(X_spectral, 2)) ./ std(X_spectral, 0, 2);
XTest_spectral = (XTest_spectral - mean(XTest_spectral, 2)) ./ std(XTest_spectral, 0, 2);
window = 5;
poly_order = 3; 
X_spectral = sgolayfilt(X_spectral, poly_order, window, [], 2); 
XTest_spectral = sgolayfilt(XTest_spectral, poly_order, window, [], 2);

[~, idx] = ismember(round(XTest_coords), labels_all(:,1:2), 'rows'); 
if any(idx == 0)
    error('Some coordinates cannot find a match in the label file');
end
true_labels_test = labels_all(idx, 3); 


% -------------------------------AE_residuals-------------------------------
inputSize = size(X_spectral, 2); 
XTrain = X_spectral;

layers = [
    featureInputLayer(inputSize)
    fullyConnectedLayer(32)
    reluLayer
    dropoutLayer(0.2)
    fullyConnectedLayer(16)
    reluLayer
    fullyConnectedLayer(3, 'Name', 'bottleneck')  
    fullyConnectedLayer(16)
    reluLayer
    fullyConnectedLayer(32)
    reluLayer
    fullyConnectedLayer(inputSize)
    regressionLayer
];

options = trainingOptions('adam', ...
    'MaxEpochs', 3, ...
    'MiniBatchSize', 64, ...
    'InitialLearnRate', 1e-3, ...
    'Shuffle', 'every-epoch', ...
    'Verbose', false, ...
    'Plots', 'training-progress', ...
    'ValidationData', {XTrain, XTrain}, ...
    'ValidationFrequency', 50, ...
    'ExecutionEnvironment','cpu', ...
    'ValidationPatience', 50); 

net = trainNetwork(XTrain, XTrain, layers, options);

X_spectral_reconstructed = predict(net, X_spectral);
absolute_differences_baseline = abs(X_spectral - X_spectral_reconstructed);
XTest_spectral_reconstructed = predict(net, XTest_spectral);
absolute_differences = abs(XTest_spectral - XTest_spectral_reconstructed);


% % -------------------------------t‑SNE-------------------------------
% rng(1);  
% Y_res = tsne(absolute_differences, ...   
%              'Algorithm','exact', ...    
%              'NumDimensions',3, ...
%              'Standardize',true, ...
%              'Perplexity',30);
% 
% Y_ori = tsne(XTest_spectral, ...         
%              'Algorithm','barneshut', ...
%              'NumDimensions',3, ...
%              'Standardize',true, ...
%              'Perplexity',30);
% 
% allY  = [Y_res; Y_ori];
% axMin_t = min(allY,[],1);
% axMax_t = max(allY,[],1);
% 
% figure;
% scatter3(Y_res(true_labels_test==1,1), Y_res(true_labels_test==1,2), Y_res(true_labels_test==1,3), ...
%          7,[0.85 0.1 0.1],'filled','MarkerEdgeAlpha',0.9,'MarkerFaceAlpha',0.9); hold on;
% scatter3(Y_res(true_labels_test==0,1), Y_res(true_labels_test==0,2), Y_res(true_labels_test==0,3), ...
%          7,[0.1 0.35 0.9],'filled','MarkerEdgeAlpha',0.9,'MarkerFaceAlpha',0.9);
% title('after CoR t-SNE');
% xlabel('t-SNE 1'); ylabel('t-SNE 2'); zlabel('t-SNE 3');
% legend({'Test normal','Test necrotic'},'FontSize',9);
% grid on; axis equal;
% xlim([axMin_t(1) axMax_t(1)]);
% ylim([axMin_t(2) axMax_t(2)]);
% zlim([axMin_t(3) axMax_t(3)]);
% view(-30,15); rotate3d on;
% 
% figure;
% scatter3(Y_ori(true_labels_test==1,1), Y_ori(true_labels_test==1,2), Y_ori(true_labels_test==1,3), ...
%          7,[0.85 0.1 0.1],'filled','MarkerEdgeAlpha',0.9,'MarkerFaceAlpha',0.9); hold on;
% scatter3(Y_ori(true_labels_test==0,1), Y_ori(true_labels_test==0,2), Y_ori(true_labels_test==0,3), ...
%          7,[0.1 0.35 0.9],'filled','MarkerEdgeAlpha',0.9,'MarkerFaceAlpha',0.9);
% title('before CoR t-SNE');
% xlabel('t-SNE 1'); ylabel('t-SNE 2'); zlabel('t-SNE 3');
% legend({'Test normal','Test necrotic'},'FontSize',9);
% grid on; axis equal;
% xlim([axMin_t(1) axMax_t(1)]);
% ylim([axMin_t(2) axMax_t(2)]);
% zlim([axMin_t(3) axMax_t(3)]);
% view(-30,15); rotate3d on;


% ----------------------------------After CoR MCD----------------------------------
XTrain_MCD = absolute_differences_baseline;
ResultMCD = mcdcov(XTrain_MCD,'plots',0,'alpha',0.89);

MD = zeros(size(absolute_differences,1),1);
for i = 1:size(absolute_differences,1)
    MD(i) = (absolute_differences(i,:) - ResultMCD.center) * pinv(ResultMCD.cov) * (absolute_differences(i,:) - ResultMCD.center)';
end
flag = MD < chi2inv(0.975,9);

predicted_test = (flag == 1); 

[accuracy, sensitivity, specificity] = calculateMetrics(true_labels_test, predicted_test);
fprintf('after CoR MCD classification performance:\naccuracy: %.2f%%\nsensitivity: %.2f%%\nspecificity: %.2f%%\n\n',...
    accuracy*100, sensitivity*100, specificity*100);

classification_result_baseline = [XTest_coords, predicted_test, true_labels_test];


% ----------------------------------Before CoR MCD----------------------------------
XTrain_MCD = X_spectral;
ResultMCD = mcdcov(XTrain_MCD,'plots',0,'alpha',0.89);

MD = zeros(size(XTest_spectral,1),1);
for i = 1:size(XTest_spectral,1)
    MD(i) = (XTest_spectral(i,:) - ResultMCD.center) * pinv(ResultMCD.cov) * (XTest_spectral(i,:) - ResultMCD.center)';
end
flag = MD < chi2inv(0.975,9);

predicted_test = (flag == 1); 

[accuracy, sensitivity, specificity] = calculateMetrics(true_labels_test, predicted_test);
fprintf('before CoR MCD classification performance:\naccuracy: %.2f%%\nsensitivity: %.2f%%\nspecificity: %.2f%%\n\n',...
    accuracy*100, sensitivity*100, specificity*100);

classification_result_original = [XTest_coords, predicted_test, true_labels_test];


% -------------------------------Classification visualization-------------------------------
function plot_predicted(result, title_str)

    figure('Position',[100 100 800 400]);
    red_mask  = (result(:,3) == 1);
    scatter(result(red_mask,1), result(red_mask,2), ...
            5, [0.85 0.2 0.2], 'filled', ...
            'DisplayName', sprintf('Predicted as normal %d', sum(red_mask)));  

    hold on;

    blue_mask = (result(:,3) == 0);
    scatter(result(blue_mask,1), result(blue_mask,2), ...
            5, [0.2 0.45 0.9], 'filled', ...
            'DisplayName', sprintf('Predicted as necrosis %d', sum(blue_mask)));

    title(title_str, 'FontWeight','bold');
    xlabel('X coordinates'); ylabel('Y coordinates');
    legend('Location','bestoutside');
    axis equal tight;
    grid on;
    set(gca,'FontSize',10,'Box','on');
end

plot_predicted(classification_result_baseline, 'after CoR · predicted results');
plot_predicted(classification_result_original, 'before CoR · predicted results');


% -------------------------------Classification performance calculation function-------------------------------
function [accuracy, sensitivity, specificity] = calculateMetrics(true_labels, predicted_labels)
    if ~isequal(size(true_labels), size(predicted_labels))
        error('Inconsistent input label dimensions');
    end
    if ~all(ismember(unique(true_labels),[0 1])) || ~all(ismember(unique(predicted_labels),[0 1]))
        error('The label must be encoded as 0/1');
    end
    
    TP = sum((predicted_labels == 0) & (true_labels == 0)); 
    TN = sum((predicted_labels == 1) & (true_labels == 1)); 
    FP = sum((predicted_labels == 0) & (true_labels == 1)); 
    FN = sum((predicted_labels == 1) & (true_labels == 0)); 
    
    accuracy = (TP + TN) / numel(true_labels);
    sensitivity = TP / (TP + FN + eps);
    specificity = TN / (TN + FP + eps);
end

