function [index,seed]=addobs(index,n,seed)
% Extends a trial subsample with one observation.

indexTot = 1:1:n;
indexDiff = setdiff(indexTot,index); %remaining indices

[random,seed]=uniran(seed);
num=floor( random * length(indexDiff) ) +1; %select index
index(end+1)=indexDiff(num);