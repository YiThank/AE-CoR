function[indexOnPlane,countOnPlane,distToPlane]=obsinplane(data,mean,zeroEigvct,centered)
    
    if ~centered
        data=bsxfun(@minus,data,mean);
    end
    
    dists=data*zeroEigvct;
    
    distToPlane=sqrt(sum(dists.^2,2));   
    distToPlane=distToPlane';
    indexOnPlane=find(distToPlane < 1e-8);        
    countOnPlane=length(indexOnPlane);    